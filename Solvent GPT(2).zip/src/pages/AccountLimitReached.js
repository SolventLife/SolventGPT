import FrameComponent7 from "../components/FrameComponent7";
import FrameComponent6 from "../components/FrameComponent6";
import FrameComponent5 from "../components/FrameComponent5";
import styles from "./AccountLimitReached.module.css";

const AccountLimitReached = () => {
  return (
    <div className={styles.accountLimitReached}>
      <FrameComponent7 />
      <main className={styles.frameParent}>
        <section className={styles.frameGroup}>
          <div className={styles.frameWrapper}>
            <div className={styles.female13Parent}>
              <img
                className={styles.female13Icon}
                loading="lazy"
                alt=""
                src="/female131@2x.png"
              />
              <div className={styles.frameContainer}>
                <div className={styles.annaParent}>
                  <b className={styles.anna}>Anna</b>
                  <div className={styles.whatIsA}>
                    what is a trade and trading market platform, please explain
                    detail?
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.upgradeButtonContainer}>
            <div className={styles.frameDiv}>
              <div className={styles.rectangleWrapper}>
                <div className={styles.frameChild} />
              </div>
              <img
                className={styles.female13Icon1}
                alt=""
                src="/female13-1@2x.png"
              />
            </div>
            <div className={styles.backgroundShape}>
              <b className={styles.solvenGpt}>Solven GPT</b>
              <div className={styles.backgroundShapeInner}>
                <div className={styles.aTradeIsATransactionWhereParent}>
                  <div className={styles.aTradeIsContainer}>
                    <p className={styles.aTradeIs}>
                      A trade is a transaction where goods, services, or
                      financial instruments are exchanged between parties,
                      typically in return for money or other goods/services. In
                      the context of financial markets, trading involves buying
                      and selling financial instruments like stocks, bonds,
                      commodities, or currencies with the aim of making a
                      profit.
                    </p>
                    <p className={styles.aTradingMarket}>
                      A trading market platform is a digital platform that
                      facilitates the buying and selling of financial
                      instruments. These platforms provide traders with access
                      to markets, tools, and resources necessary for executing
                      trades efficiently. Here's a detailed breakdown:
                    </p>
                    <ol className={styles.marketAccessTradingPlatfor}>
                      <li className={styles.marketAccessTrading}>
                        Market Access: Trading platforms connect traders to
                        various financial markets such as stock exchanges,
                        commodities exchanges, foreign exchange markets, and
                        cryptocurrency exchanges. They provide access to
                        real-time market data, including prices, volumes, and
                        historical trends, enabling traders to make informed
                        decisions.
                      </li>
                      <li className={styles.orderPlacementTraders}>
                        Order Placement: Traders can place buy or sell orders
                        directly through the platform. They can specify
                        parameters like quantity, price, and order type (market
                        order, limit order, stop order, etc.). The platform then
                        routes these orders to the relevant market for
                        execution.
                      </li>
                      <li className={styles.executionOnceAn}>
                        Execution: Once an order is placed, the platform
                        executes the trade based on the prevailing market
                        conditions. For example, if a trader submits a market
                        order to buy 100 shares of a stock, the platform will
                        execute the trade at the best available market price.
                      </li>
                      <li className={styles.chartingAndAnalysis}>
                        Charting and Analysis Tools: Trading platforms often
                        provide a range of analytical tools and charts to help
                        traders analyze market trends, identify trading
                        opportunities, and manage risk. These tools may include
                        technical indicators, charting patterns, and drawing
                        tools.
                      </li>
                      <li>
                        Risk Management: Effective risk management is crucial in
                        trading. Platforms offer features like stop-loss orders,
                        which automatically sell a security if it reaches a
                        certain price to limit potential losses. They may also
                        provide risk assessment tools and portfolio analysis to
                        help traders manage their exposure.
                      </li>
                    </ol>
                  </div>
                  <div className={styles.content}>
                    <img
                      className={styles.logoIcon}
                      alt=""
                      src="/logo-11@2x.png"
                    />
                    <div className={styles.contentArea}>
                      <img
                        className={styles.iconParkOutlineattention}
                        loading="lazy"
                        alt=""
                        src="/iconparkoutlineattention.svg"
                      />
                      <div className={styles.accountLimit}>
                        <h3 className={styles.yourAccountHas}>
                          Your account has reached the limit
                        </h3>
                      </div>
                    </div>
                    <div className={styles.helloWeNoticedThatContainer}>
                      <p className={styles.hello}>Hello,</p>
                      <p className={styles.weNoticedThat}>
                        We noticed that you reached the limit for your account,
                        please upgrade your plan to ensure you can continue
                        using Solvent GPT ™ without interruption.
                      </p>
                    </div>
                    <button className={styles.button}>
                      <div className={styles.button1}>
                        <b className={styles.upgradeNow}>Upgrade Now</b>
                      </div>
                    </button>
                    <img
                      className={styles.phxIcon}
                      loading="lazy"
                      alt=""
                      src="/phx1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <FrameComponent6 />
      </main>
      <FrameComponent5 />
      <div className={styles.accountLimitReachedChild} />
    </div>
  );
};

export default AccountLimitReached;
