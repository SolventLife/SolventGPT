import styles from "./FrameComponent18.module.css";

const FrameComponent18 = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.logoParent}>
        <img
          className={styles.logoIcon}
          loading="lazy"
          alt=""
          src="/logo@2x.png"
        />
        <div className={styles.navbar}>
          <div className={styles.menuList}>
            <div className={styles.menuList1}>
              <b className={styles.newChat}>New Chat</b>
            </div>
            <img
              className={styles.fluentnoteEdit20RegularIcon}
              alt=""
              src="/fluentnoteedit20regular.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.previousDaysSummary}>
        <div className={styles.previousDaysSummary1}>
          <div className={styles.yesterday}>Yesterday</div>
          <div className={styles.previousDaysSummary2}>
            <div className={styles.giveMeA}>Give me a summary</div>
            <div className={styles.showMeThe}>Show me the top gain...</div>
            <div className={styles.whatIsThe}>What is the premium...</div>
            <div className={styles.whatIsThe1}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.summaryBoxesWrapper}>
        <div className={styles.summaryBoxes}>
          <div className={styles.previous30Days}>Previous 30 Days</div>
          <div className={styles.summaryBoxes1}>
            <div className={styles.giveMeA1}>Give me a summary</div>
            <div className={styles.showMeThe1}>Show me the top gaine...</div>
            <div className={styles.whatIsThe2}>What is the premium...</div>
            <div className={styles.whatIsThe3}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <img
            className={styles.frameChild}
            alt=""
            src="/group-1000005043.svg"
          />
          <div className={styles.upgradePro}>
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent18;
