import { useMemo } from "react";
import styles from "./FrameComponent2.module.css";

const FrameComponent2 = ({
  logo,
  helix21,
  premium,
  unlimitedPrompts,
  changePlan,
  frameDivMargin,
  frameDivPosition,
  frameDivTop,
  frameDivLeft,
  frameDivPadding,
  frameDivPadding1,
  divWidth,
  divPadding,
  premiumMinWidth,
  unlimitedPromptsMinWidth,
  buttonBackgroundColor,
  buttonPadding,
  changePlanMinWidth,
  changePlanFontWeight,
}) => {
  const frameDivStyle = useMemo(() => {
    return {
      margin: frameDivMargin,
      position: frameDivPosition,
      top: frameDivTop,
      left: frameDivLeft,
    };
  }, [frameDivMargin, frameDivPosition, frameDivTop, frameDivLeft]);

  const frameDiv1Style = useMemo(() => {
    return {
      padding: frameDivPadding,
    };
  }, [frameDivPadding]);

  const frameDiv2Style = useMemo(() => {
    return {
      padding: frameDivPadding1,
    };
  }, [frameDivPadding1]);

  const divStyle = useMemo(() => {
    return {
      width: divWidth,
      padding: divPadding,
    };
  }, [divWidth, divPadding]);

  const premiumStyle = useMemo(() => {
    return {
      minWidth: premiumMinWidth,
    };
  }, [premiumMinWidth]);

  const unlimitedPromptsStyle = useMemo(() => {
    return {
      minWidth: unlimitedPromptsMinWidth,
    };
  }, [unlimitedPromptsMinWidth]);

  const buttonStyle = useMemo(() => {
    return {
      backgroundColor: buttonBackgroundColor,
      padding: buttonPadding,
    };
  }, [buttonBackgroundColor, buttonPadding]);

  const changePlanStyle = useMemo(() => {
    return {
      minWidth: changePlanMinWidth,
      fontWeight: changePlanFontWeight,
    };
  }, [changePlanMinWidth, changePlanFontWeight]);

  return (
    <div className={styles.logoContainerParent} style={frameDivStyle}>
      <div className={styles.logoContainer}>
        <img className={styles.logoIcon} loading="lazy" alt="" src={logo} />
        <div className={styles.navbar}>
          <div className={styles.menuList}>
            <div className={styles.newChatWrapper}>
              <b className={styles.newChat}>New Chat</b>
            </div>
            <img
              className={styles.fluentnoteEdit20RegularIcon}
              alt=""
              src="/fluentnoteedit20regular.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.frameWrapper} style={frameDiv1Style}>
        <div className={styles.yesterdayParent}>
          <div className={styles.yesterday}>Yesterday</div>
          <div className={styles.giveMeASummaryParent}>
            <div className={styles.giveMeA}>Give me a summary</div>
            <div className={styles.showMeThe}>Show me the top gain...</div>
            <div className={styles.whatIsThe}>What is the premium...</div>
            <div className={styles.whatIsThe1}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.helixContainerWrapper} style={frameDiv2Style}>
        <div className={styles.helixContainer}>
          <div className={styles.previous30Days}>Previous 30 Days</div>
          <div className={styles.giveMeASummaryGroup}>
            <div className={styles.giveMeA1}>Give me a summary</div>
            <div className={styles.showMeThe1}>Show me the top gaine...</div>
            <div className={styles.whatIsThe2}>What is the premium...</div>
            <div className={styles.whatIsThe3}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.changePlanButton}>
        <div className={styles.helix21Parent}>
          <img
            className={styles.helix21Icon}
            loading="lazy"
            alt=""
            src={helix21}
          />
          <div className={styles.div} style={divStyle}>
            <div className={styles.eye}>Your current plan</div>
            <div className={styles.inner}>
              <div className={styles.premiumWrapper}>
                <h3 className={styles.premium} style={premiumStyle}>
                  {premium}
                </h3>
              </div>
            </div>
            <div
              className={styles.unlimitedPrompts}
              style={unlimitedPromptsStyle}
            >
              {unlimitedPrompts}
            </div>
          </div>
          <button className={styles.button}>
            <div className={styles.button1} style={buttonStyle}>
              <div className={styles.changePlan} style={changePlanStyle}>
                {changePlan}
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent2;
