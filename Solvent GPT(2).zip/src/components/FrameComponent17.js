import styles from "./FrameComponent17.module.css";

const FrameComponent17 = () => {
  return (
    <header className={styles.frameParent}>
      <div className={styles.upgradeButtonWrapper}>
        <div className={styles.upgradeButton}>
          <img
            className={styles.upgradeButtonChild}
            alt=""
            src="/group-1000005043.svg"
          />
          <div className={styles.upgradeButton1}>
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
      <div className={styles.female13}>
        <div className={styles.proWrapper}>
          <div className={styles.pro}>PRO</div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent17;
