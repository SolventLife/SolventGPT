import { useMemo } from "react";
import styles from "./FrameComponent1.module.css";

const FrameComponent1 = ({ propDebugCommit, propGap, propDebugCommit1 }) => {
  const profileIconStyle = useMemo(() => {
    return {
      debugCommit: propDebugCommit,
    };
  }, [propDebugCommit]);

  const frameDiv3Style = useMemo(() => {
    return {
      gap: propGap,
      debugCommit: propDebugCommit1,
    };
  }, [propGap, propDebugCommit1]);

  return (
    <div className={styles.frameParent}>
      <div className={styles.profileWrapper}>
        <img
          className={styles.profileIcon}
          loading="lazy"
          alt=""
          src="/profile@2x.png"
          style={profileIconStyle}
        />
      </div>
      <div className={styles.frameGroup} style={frameDiv3Style}>
        <div className={styles.rectangleWrapper}>
          <div className={styles.frameChild} />
        </div>
        <h1 className={styles.text}>How can I help you today?</h1>
      </div>
    </div>
  );
};

export default FrameComponent1;
