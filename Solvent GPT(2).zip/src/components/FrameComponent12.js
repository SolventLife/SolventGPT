import styles from "./FrameComponent12.module.css";

const FrameComponent12 = () => {
  return (
    <div className={styles.previousDaysDataParent}>
      <div className={styles.previousDaysData}>
        <img
          className={styles.logoIcon}
          loading="lazy"
          alt=""
          src="/logo@2x.png"
        />
        <div className={styles.navbar}>
          <div className={styles.menuList}>
            <div className={styles.summaryArea}>
              <b className={styles.newChat}>New Chat</b>
            </div>
            <img
              className={styles.fluentnoteEdit20RegularIcon}
              alt=""
              src="/fluentnoteedit20regular.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.yesterdayDataWrapper}>
        <div className={styles.yesterdayData}>
          <div className={styles.yesterday}>Yesterday</div>
          <div className={styles.confirmationMessage}>
            <div className={styles.giveMeA}>Give me a summary</div>
            <div className={styles.showMeThe}>Show me the top gain...</div>
            <div className={styles.whatIsThe}>What is the premium...</div>
            <div className={styles.whatIsThe1}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.prevDaysSummarizer}>
        <div className={styles.previous30DaysParent}>
          <div className={styles.previous30Days}>Previous 30 Days</div>
          <div className={styles.giveMeASummaryParent}>
            <div className={styles.giveMeA1}>Give me a summary</div>
            <div className={styles.showMeThe1}>Show me the top gaine...</div>
            <div className={styles.whatIsThe2}>What is the premium...</div>
            <div className={styles.whatIsThe3}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.femaleIcon}>
        <div className={styles.frameParent}>
          <img
            className={styles.frameChild}
            alt=""
            src="/group-1000005043.svg"
          />
          <div className={styles.proPrompt}>
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent12;
