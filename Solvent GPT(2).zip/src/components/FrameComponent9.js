import MenuList from "./MenuList";
import MenuList1 from "./MenuList1";
import styles from "./FrameComponent9.module.css";

const FrameComponent9 = () => {
  return (
    <section className={styles.summaryLabelTSLAParent}>
      <div className={styles.summaryLabelTSLA} />
      <div className={styles.frameWrapper}>
        <div className={styles.frameParent}>
          <div className={styles.googleSignInButtonWrapper}>
            <div className={styles.googleSignInButton}>
              <MenuList />
              <MenuList1
                showMeTheTopGainers="Show me the top gainers"
                inTheTechSectorThisMonth="In the tech sector this month."
              />
              <MenuList1
                showMeTheTopGainers="Give me a summary"
                inTheTechSectorThisMonth="A.I related stocks in a table."
                menuListWidth="469px"
                menuListPadding="var(--padding-base-5) var(--padding-5xl)"
              />
              <MenuList1
                showMeTheTopGainers="What is the premium for SPY Call"
                inTheTechSectorThisMonth="Expiring next Friday, strike price between 450 to 500?"
                menuListWidth="unset"
                menuListPadding="var(--padding-base-5) var(--padding-13xl) var(--padding-base-5) var(--padding-4xl)"
              />
            </div>
          </div>
          <div className={styles.frameGroup}>
            <div className={styles.textParent}>
              <input
                className={styles.text}
                placeholder="Ask Solvent.Life ™ Neural Network..."
                type="text"
              />
              <img
                className={styles.flowbiteuploadOutlineIcon}
                alt=""
                src="/flowbiteuploadoutline.svg"
              />
            </div>
            <div className={styles.text1}>
              Solvent GPT ™ can make mistakes. Consider checking important
              information.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent9;
