import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import styles from "./LoginPremium.module.css";

const LoginPremium = () => {
  return (
    <div className={styles.loginPremium}>
      <FrameComponent2
        logo="/logo@2x.png"
        helix21="/helix2-1@2x.png"
        premium="Premium"
        unlimitedPrompts="Unlimited Prompts"
        changePlan="Change Plan"
      />
      <main className={styles.frameParent}>
        <header className={styles.female13Wrapper}>
          <div className={styles.female13}>
            <div className={styles.premiumWrapper}>
              <div className={styles.premium}>{`Premium `}</div>
            </div>
          </div>
        </header>
        <section className={styles.filterLabel}>
          <FrameComponent1 />
          <FrameComponent />
        </section>
      </main>
    </div>
  );
};

export default LoginPremium;
