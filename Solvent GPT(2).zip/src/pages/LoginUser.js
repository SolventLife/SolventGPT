import FrameComponent10 from "../components/FrameComponent10";
import FrameComponent9 from "../components/FrameComponent9";
import Content1 from "../components/Content1";
import styles from "./LoginUser.module.css";

const LoginUser = () => {
  return (
    <div className={styles.loginUser}>
      <FrameComponent10 />
      <main className={styles.frameParent}>
        <div className={styles.profileWrapper}>
          <img
            className={styles.profileIcon}
            loading="lazy"
            alt=""
            src="/profile3@2x.png"
          />
        </div>
        <FrameComponent9 />
      </main>
      <div className={styles.boxOfInfo}>
        <div className={styles.summaryMenuHolder}>
          <div className={styles.frameGroup}>
            <img
              className={styles.frameChild}
              alt=""
              src="/group-1000005043.svg"
            />
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
      <div className={styles.pictureAndProfile} />
      <Content1 />
    </div>
  );
};

export default LoginUser;
