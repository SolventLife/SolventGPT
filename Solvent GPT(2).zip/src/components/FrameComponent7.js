import styles from "./FrameComponent7.module.css";

const FrameComponent7 = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.helixContainerParent}>
        <div className={styles.helixContainer}>
          <img
            className={styles.logoIcon}
            loading="lazy"
            alt=""
            src="/logo2@2x.png"
          />
          <div className={styles.navbar}>
            <div className={styles.menuList}>
              <div className={styles.upgradeButton}>
                <b className={styles.newChat}>New Chat</b>
              </div>
              <img
                className={styles.fluentnoteEdit20RegularIcon}
                alt=""
                src="/fluentnoteedit20regular.svg"
              />
            </div>
          </div>
        </div>
        <div className={styles.frameWrapper}>
          <div className={styles.frameGroup}>
            <div className={styles.yesterdayParent}>
              <div className={styles.yesterday}>Yesterday</div>
              <div className={styles.giveMeA}>Give me a summary</div>
            </div>
            <div className={styles.showMeThe}>Show me the top gain...</div>
            <div className={styles.whatIsThe}>What is the premium...</div>
            <div className={styles.whatIsThe1}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.previous30DaysParent}>
          <div className={styles.previous30Days}>Previous 30 Days</div>
          <div className={styles.giveMeASummaryParent}>
            <div className={styles.giveMeA1}>Give me a summary</div>
            <div className={styles.showMeThe1}>Show me the top gaine...</div>
            <div className={styles.whatIsThe2}>What is the premium...</div>
            <div className={styles.whatIsThe3}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.frameDiv}>
        <div className={styles.helix21Parent}>
          <img
            className={styles.helix21Icon}
            loading="lazy"
            alt=""
            src="/helix2-11@2x.png"
          />
          <div className={styles.buttonContainer}>
            <div className={styles.text}>Your current plan</div>
            <div className={styles.buttonContainerInner}>
              <div className={styles.freeWrapper}>
                <h3 className={styles.free}>Free</h3>
              </div>
            </div>
            <div className={styles.prompts}>1/5 Prompts</div>
          </div>
          <button className={styles.button}>
            <div className={styles.button1}>
              <b className={styles.upgradePlan}>Upgrade Plan</b>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent7;
