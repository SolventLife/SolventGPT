import styles from "./FrameComponent11.module.css";

const FrameComponent11 = () => {
  return (
    <header className={styles.frameParent}>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <img
            className={styles.frameChild}
            alt=""
            src="/group-1000005043.svg"
          />
          <div className={styles.proPrompt}>
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
      <div className={styles.female13}>
        <div className={styles.proWrapper}>
          <div className={styles.pro}>PRO</div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent11;
