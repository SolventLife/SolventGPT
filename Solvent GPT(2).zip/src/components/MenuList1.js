import { useMemo } from "react";
import styles from "./MenuList1.module.css";

const MenuList1 = ({
  showMeTheTopGainers,
  inTheTechSectorThisMonth,
  menuListWidth,
  menuListPadding,
}) => {
  const menuListStyle = useMemo(() => {
    return {
      width: menuListWidth,
      padding: menuListPadding,
    };
  }, [menuListWidth, menuListPadding]);

  return (
    <div className={styles.menuList} style={menuListStyle}>
      <div className={styles.showMeTheTopGainersParent}>
        <div className={styles.showMeThe}>{showMeTheTopGainers}</div>
        <div className={styles.inTheTech}>{inTheTechSectorThisMonth}</div>
      </div>
    </div>
  );
};

export default MenuList1;
