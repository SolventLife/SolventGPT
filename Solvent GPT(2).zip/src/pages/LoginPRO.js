import FrameComponent25 from "../components/FrameComponent25";
import FrameComponent24 from "../components/FrameComponent24";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent23 from "../components/FrameComponent23";
import styles from "./LoginPRO.module.css";

const LoginPRO = () => {
  return (
    <div className={styles.loginPro}>
      <FrameComponent25 />
      <main className={styles.frameParent}>
        <FrameComponent24 pRO="PRO" />
        <section className={styles.frameGroup}>
          <FrameComponent1
            propDebugCommit="unset"
            propGap="20px"
            propDebugCommit1="unset"
          />
          <FrameComponent23 />
        </section>
      </main>
    </div>
  );
};

export default LoginPRO;
