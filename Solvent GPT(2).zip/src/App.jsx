import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Login from "./pages/Login";
import LoginPremium from "./pages/LoginPremium";
import LoginCreateAccount from "./pages/LoginCreateAccount";
import AccountLimitReached from "./pages/AccountLimitReached";
import UpgradeLogin from "./pages/UpgradeLogin";
import LoginUser from "./pages/LoginUser";
import UpgradedPro from "./pages/UpgradedPro";
import UpgradedPremium from "./pages/UpgradedPremium";
import UpgradedLifetime from "./pages/UpgradedLifetime";
import LoginFree from "./pages/LoginFree";
import LoginPRO from "./pages/LoginPRO";
import LoginLifetime from "./pages/LoginLifetime";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/-login-premium":
        title = "";
        metaDescription = "";
        break;
      case "/-login-create-account":
        title = "";
        metaDescription = "";
        break;
      case "/account-limit-reached":
        title = "";
        metaDescription = "";
        break;
      case "/upgrade-login":
        title = "";
        metaDescription = "";
        break;
      case "/login-user":
        title = "";
        metaDescription = "";
        break;
      case "/upgraded-pro":
        title = "";
        metaDescription = "";
        break;
      case "/upgraded-premium":
        title = "";
        metaDescription = "";
        break;
      case "/upgraded-lifetime":
        title = "";
        metaDescription = "";
        break;
      case "/-login-free":
        title = "";
        metaDescription = "";
        break;
      case "/-login-pro":
        title = "";
        metaDescription = "";
        break;
      case "/-login-lifetime":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/-login-premium" element={<LoginPremium />} />
      <Route path="/-login-create-account" element={<LoginCreateAccount />} />
      <Route path="/account-limit-reached" element={<AccountLimitReached />} />
      <Route path="/upgrade-login" element={<UpgradeLogin />} />
      <Route path="/login-user" element={<LoginUser />} />
      <Route path="/upgraded-pro" element={<UpgradedPro />} />
      <Route path="/upgraded-premium" element={<UpgradedPremium />} />
      <Route path="/upgraded-lifetime" element={<UpgradedLifetime />} />
      <Route path="/-login-free" element={<LoginFree />} />
      <Route path="/-login-pro" element={<LoginPRO />} />
      <Route path="/-login-lifetime" element={<LoginLifetime />} />
    </Routes>
  );
}
export default App;
