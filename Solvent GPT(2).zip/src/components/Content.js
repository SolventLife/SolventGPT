import styles from "./Content.module.css";

const Content = () => {
  return (
    <div className={styles.content}>
      <div className={styles.createAccountBtnWrapper}>
        <div className={styles.createAccountBtn}>
          <img
            className={styles.phxIcon}
            loading="lazy"
            alt=""
            src="/phx.svg"
          />
          <div className={styles.inputerField}>
            <img
              className={styles.logoIcon}
              loading="lazy"
              alt=""
              src="/logo-1@2x.png"
            />
          </div>
        </div>
      </div>
      <div className={styles.alreadyHaveAccountBtn}>
        <b className={styles.createAccount}>Create account</b>
      </div>
      <div className={styles.inputHelper}>
        <div className={styles.inputerField1}>
          <div className={styles.input}>
            <div className={styles.email}>Email</div>
            <div className={styles.field}>
              <img
                className={styles.vuesaxlinearhomeIcon}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.outlineMessagesConversati}
                alt=""
                src="/outline--messages-conversation----letter.svg"
              />
              <input
                className={styles.yourEmail}
                placeholder="your email"
                type="text"
              />
              <img
                className={styles.vuesaxlinearhomeIcon1}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
            </div>
          </div>
        </div>
        <div className={styles.inputerField2}>
          <div className={styles.input1}>
            <div className={styles.password}>Password</div>
            <div className={styles.field1}>
              <img
                className={styles.vuesaxlinearhomeIcon2}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.solarpasswordLineDuotoneIcon}
                alt=""
                src="/solarpasswordlineduotone.svg"
              />
              <input
                className={styles.yourPassword}
                placeholder="your password"
                type="text"
              />
              <img
                className={styles.vuesaxlinearhomeIcon3}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.mingcuteeyeLineIcon}
                alt=""
                src="/mingcuteeyeline.svg"
              />
            </div>
          </div>
        </div>
      </div>
      <button className={styles.button}>
        <div className={styles.registerAccount}>Register Account</div>
      </button>
      <div className={styles.contentInner}>
        <div className={styles.alreadyHaveAnAccountParent}>
          <div className={styles.alreadyHaveAn}>Already have an account?</div>
          <div className={styles.logIn}>Log in</div>
        </div>
      </div>
      <div className={styles.upgradeToProBtn}>
        <div className={styles.deviderWrapper}>
          <div className={styles.devider} />
        </div>
        <div className={styles.orSignUp}>Or sign up with</div>
        <div className={styles.deviderContainer}>
          <div className={styles.devider1} />
        </div>
      </div>
      <button className={styles.button1}>
        <img className={styles.layer1Icon} alt="" src="/layer-1.svg" />
        <div className={styles.signUpWithGoogleWrapper}>
          <div className={styles.signUpWith}>Sign up with Google</div>
        </div>
      </button>
    </div>
  );
};

export default Content;
