import styles from "./Content1.module.css";

const Content1 = () => {
  return (
    <div className={styles.content}>
      <div className={styles.dataEntryFields}>
        <div className={styles.fieldContainer}>
          <img
            className={styles.phxIcon}
            loading="lazy"
            alt=""
            src="/phx.svg"
          />
          <div className={styles.logoWrapper}>
            <img
              className={styles.logoIcon}
              loading="lazy"
              alt=""
              src="/logo-12@2x.png"
            />
          </div>
        </div>
      </div>
      <div className={styles.loginWrapper}>
        <b className={styles.login}>Login</b>
      </div>
      <div className={styles.inputHelper}>
        <div className={styles.inputerField}>
          <div className={styles.input}>
            <div className={styles.email}>Email</div>
            <div className={styles.field}>
              <img
                className={styles.vuesaxlinearhomeIcon}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.outlineMessagesConversati}
                alt=""
                src="/outline--messages-conversation----letter.svg"
              />
              <input
                className={styles.yourEmail}
                placeholder="your email"
                type="text"
              />
              <img
                className={styles.vuesaxlinearhomeIcon1}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
            </div>
          </div>
        </div>
        <div className={styles.inputerField1}>
          <div className={styles.input1}>
            <div className={styles.password}>Password</div>
            <div className={styles.field1}>
              <img
                className={styles.vuesaxlinearhomeIcon2}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.solarpasswordLineDuotoneIcon}
                alt=""
                src="/solarpasswordlineduotone.svg"
              />
              <input
                className={styles.yourPassword}
                placeholder="your password"
                type="text"
              />
              <img
                className={styles.vuesaxlinearhomeIcon3}
                alt=""
                src="/vuesaxlinearhome.svg"
              />
              <img
                className={styles.mingcuteeyeLineIcon}
                alt=""
                src="/mingcuteeyeline.svg"
              />
            </div>
          </div>
        </div>
      </div>
      <button className={styles.button}>
        <div className={styles.login1}>Login</div>
      </button>
      <div className={styles.contentInner}>
        <div className={styles.dontHaveAnAccountParent}>
          <div className={styles.dontHaveAn}>Don’t have an account?</div>
          <div className={styles.signUpHere}> Sign up here</div>
        </div>
      </div>
      <div className={styles.devider}>
        <div className={styles.deviderWrapper}>
          <div className={styles.devider1} />
        </div>
        <div className={styles.orSignIn}>Or sign in with</div>
        <div className={styles.deviderContainer}>
          <div className={styles.devider2} />
        </div>
      </div>
      <button className={styles.button1}>
        <img className={styles.layer1Icon} alt="" src="/layer-1.svg" />
        <div className={styles.signInWithGoogleWrapper}>
          <div className={styles.signInWith}>Sign in with Google</div>
        </div>
      </button>
    </div>
  );
};

export default Content1;
