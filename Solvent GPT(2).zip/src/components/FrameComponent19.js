import styles from "./FrameComponent19.module.css";

const FrameComponent19 = () => {
  return (
    <footer className={styles.frameWrapper}>
      <div className={styles.frameParent}>
        <div className={styles.textParent}>
          <div className={styles.text}>
            Ask Solvent.Life ™ Neural Network...
          </div>
          <img
            className={styles.flowbiteuploadOutlineIcon}
            alt=""
            src="/flowbiteuploadoutline.svg"
          />
        </div>
        <div className={styles.text1}>
          Solvent GPT ™ can make mistakes. Consider checking important
          information.
        </div>
      </div>
    </footer>
  );
};

export default FrameComponent19;
