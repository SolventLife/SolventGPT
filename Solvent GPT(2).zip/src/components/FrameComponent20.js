import styles from "./FrameComponent20.module.css";

const FrameComponent20 = () => {
  return (
    <div className={styles.frameWrapper}>
      <div className={styles.frameParent}>
        <div className={styles.frameContainer}>
          <div className={styles.menuListParent}>
            <div className={styles.menuList}>
              <div className={styles.giveMeASummaryParent}>
                <div className={styles.giveMeA}>Give me a summary</div>
                <input
                  className={styles.ofTslas2023}
                  placeholder="of TSLA’s 2023 earning report."
                  type="text"
                />
              </div>
            </div>
            <div className={styles.menuList1}>
              <div className={styles.showMeTheTopGainersParent}>
                <div className={styles.showMeThe}>Show me the top gainers</div>
                <input
                  className={styles.inTheTech}
                  placeholder="In the tech sector this month."
                  type="text"
                />
              </div>
            </div>
            <div className={styles.menuList2}>
              <div className={styles.giveMeASummaryGroup}>
                <div className={styles.giveMeA1}>Give me a summary</div>
                <input
                  className={styles.aiRelatedStocks}
                  placeholder="A.I related stocks in a table."
                  type="text"
                />
              </div>
            </div>
            <div className={styles.menuList3}>
              <div className={styles.whatIsThePremiumForSpyCaParent}>
                <div className={styles.whatIsThe}>
                  What is the premium for SPY Call
                </div>
                <input
                  className={styles.expiringNextFriday}
                  placeholder="Expiring next Friday, strike price between 450 to 500?"
                  type="text"
                />
              </div>
            </div>
          </div>
        </div>
        <footer className={styles.frameGroup}>
          <div className={styles.textParent}>
            <input
              className={styles.text}
              placeholder="Ask Solvent.Life ™ Neural Network..."
              type="text"
            />
            <img
              className={styles.flowbiteuploadOutlineIcon}
              alt=""
              src="/flowbiteuploadoutline.svg"
            />
          </div>
          <div className={styles.text1}>
            Solvent GPT ™ can make mistakes. Consider checking important
            information.
          </div>
        </footer>
      </div>
    </div>
  );
};

export default FrameComponent20;
