import FrameComponent3 from "../components/FrameComponent3";
import MenuList from "../components/MenuList";
import FrameComponent2 from "../components/FrameComponent2";
import styles from "./Login.module.css";

const Login = () => {
  return (
    <div className={styles.login}>
      <FrameComponent3 />
      <main className={styles.frameParent}>
        <header className={styles.frameWrapper}>
          <button className={styles.streamlineaiNetworkSparkSoParent}>
            <img
              className={styles.streamlineaiNetworkSparkSoIcon}
              alt=""
              src="/streamlineainetworksparksolid.svg"
            />
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </button>
        </header>
        <section className={styles.frameContainer}>
          <div className={styles.frameGroup}>
            <div className={styles.frameDiv}>
              <div className={styles.frameParent1}>
                <div className={styles.profileWrapper}>
                  <img
                    className={styles.profileIcon}
                    loading="lazy"
                    alt=""
                    src="/profile1@2x.png"
                  />
                </div>
                <div className={styles.textParent}>
                  <h1 className={styles.text}>How can I help you today?</h1>
                  <div className={styles.navbar}>
                    <div className={styles.leftContent}>
                      <div className={styles.menuListParent}>
                        <button className={styles.menuList}>
                          <b className={styles.signUp}>Sign up</b>
                        </button>
                        <button className={styles.menuList1}>
                          <b className={styles.login1}>Login</b>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.menuListGroup}>
              <MenuList />
              <div className={styles.menuList2}>
                <div className={styles.showMeTheTopGainersParent}>
                  <div className={styles.showMeThe}>
                    Show me the top gainers
                  </div>
                  <input
                    className={styles.inTheTech}
                    placeholder="In the tech sector this month."
                    type="text"
                  />
                </div>
              </div>
              <div className={styles.menuList3}>
                <div className={styles.giveMeASummaryParent}>
                  <div className={styles.giveMeA}>Give me a summary</div>
                  <input
                    className={styles.aiRelatedStocks}
                    placeholder="A.I related stocks in a table."
                    type="text"
                  />
                </div>
              </div>
              <div className={styles.menuList4}>
                <div className={styles.whatIsThePremiumForSpyCaParent}>
                  <div className={styles.whatIsThe}>
                    What is the premium for SPY Call
                  </div>
                  <input
                    className={styles.expiringNextFriday}
                    placeholder="Expiring next Friday, strike price between 450 to 500?"
                    type="text"
                  />
                </div>
              </div>
            </div>
            <FrameComponent2 />
          </div>
        </section>
      </main>
    </div>
  );
};

export default Login;
