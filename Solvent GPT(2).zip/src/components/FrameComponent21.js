import styles from "./FrameComponent21.module.css";

const FrameComponent2 = () => {
  return (
    <footer className={styles.frameParent}>
      <div className={styles.textParent}>
        <input
          className={styles.text}
          placeholder="Ask Solvent.Life ™ Neural Network..."
          type="text"
        />
        <img
          className={styles.flowbiteuploadOutlineIcon}
          alt=""
          src="/flowbiteuploadoutline.svg"
        />
      </div>
      <div className={styles.text1}>
        Solvent GPT ™ can make mistakes. Consider checking important
        information.
      </div>
    </footer>
  );
};

export default FrameComponent2;
