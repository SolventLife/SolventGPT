import styles from "./MenuList.module.css";

const MenuList = () => {
  return (
    <div className={styles.menuList}>
      <div className={styles.giveMeASummaryParent}>
        <div className={styles.giveMeA}>Give me a summary</div>
        <input
          className={styles.ofTslas2023}
          placeholder="of TSLA’s 2023 earning report."
          type="text"
        />
      </div>
    </div>
  );
};

export default MenuList;
