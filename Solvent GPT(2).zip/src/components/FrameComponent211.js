import styles from "./FrameComponent211.module.css";

const FrameComponent21 = () => {
  return (
    <header className={styles.frameParent}>
      <button className={styles.streamlineaiNetworkSparkSoParent}>
        <img
          className={styles.streamlineaiNetworkSparkSoIcon}
          alt=""
          src="/streamlineainetworksparksolid.svg"
        />
        <b className={styles.upgradeToPro}>Upgrade to Pro</b>
      </button>
      <div className={styles.female13}>
        <div className={styles.freeWrapper}>
          <div className={styles.free}>Free</div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent21;
