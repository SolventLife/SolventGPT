import { useMemo } from "react";
import styles from "./FrameComponent24.module.css";

const FrameComponent24 = ({
  pRO,
  propPadding,
  propBackgroundColor,
  propMinWidth,
}) => {
  const female13Style = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const frameDiv4Style = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
    };
  }, [propBackgroundColor]);

  const pROStyle = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  return (
    <header className={styles.female13Wrapper}>
      <div className={styles.female13} style={female13Style}>
        <div className={styles.proWrapper} style={frameDiv4Style}>
          <div className={styles.pro} style={pROStyle}>
            {pRO}
          </div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent24;
