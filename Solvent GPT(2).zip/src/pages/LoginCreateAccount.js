import CreateAccountButton from "../components/CreateAccountButton";
import FrameComponent4 from "../components/FrameComponent4";
import Content from "../components/Content";
import styles from "./LoginCreateAccount.module.css";

const LoginCreateAccount = () => {
  return (
    <div className={styles.loginCreateAccount}>
      <CreateAccountButton />
      <main className={styles.frameParent}>
        <div className={styles.profileWrapper}>
          <img
            className={styles.profileIcon}
            loading="lazy"
            alt=""
            src="/profile2@2x.png"
          />
        </div>
        <FrameComponent4 />
      </main>
      <div className={styles.alreadyHaveAnAccountFRA}>
        <div className={styles.profileContainer}>
          <div className={styles.frameGroup}>
            <img
              className={styles.frameChild}
              alt=""
              src="/group-1000005043.svg"
            />
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
      <div className={styles.loginCreateAccountChild} />
      <Content />
    </div>
  );
};

export default LoginCreateAccount;
