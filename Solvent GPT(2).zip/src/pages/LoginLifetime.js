import FrameComponent26 from "../components/FrameComponent26";
import FrameComponent24 from "../components/FrameComponent24";
import FrameComponent1 from "../components/FrameComponent1";
import styles from "./LoginLifetime.module.css";

const LoginLifetime = () => {
  return (
    <div className={styles.loginLifetime}>
      <FrameComponent26 />
      <main className={styles.frameParent}>
        <FrameComponent24
          pRO="Lifetime"
          propPadding="var(--padding-23xl-5) var(--padding-12xs) 0px"
          propBackgroundColor="#95a4fc"
          propMinWidth="32px"
        />
        <section className={styles.frameGroup}>
          <FrameComponent1
            propDebugCommit="unset"
            propGap="20px"
            propDebugCommit1="unset"
          />
          <div className={styles.frameWrapper}>
            <div className={styles.frameContainer}>
              <div className={styles.frameDiv}>
                <div className={styles.menuListParent}>
                  <div className={styles.menuList}>
                    <div className={styles.giveMeASummaryParent}>
                      <div className={styles.giveMeA}>Give me a summary</div>
                      <input
                        className={styles.ofTslas2023}
                        placeholder="of TSLA’s 2023 earning report."
                        type="text"
                      />
                    </div>
                  </div>
                  <div className={styles.menuList1}>
                    <div className={styles.showMeTheTopGainersParent}>
                      <div className={styles.showMeThe}>
                        Show me the top gainers
                      </div>
                      <input
                        className={styles.inTheTech}
                        placeholder="In the tech sector this month."
                        type="text"
                      />
                    </div>
                  </div>
                  <div className={styles.menuList2}>
                    <div className={styles.giveMeASummaryGroup}>
                      <div className={styles.giveMeA1}>Give me a summary</div>
                      <input
                        className={styles.aiRelatedStocks}
                        placeholder="A.I related stocks in a table."
                        type="text"
                      />
                    </div>
                  </div>
                  <div className={styles.menuList3}>
                    <div className={styles.whatIsThePremiumForSpyCaParent}>
                      <div className={styles.whatIsThe}>
                        What is the premium for SPY Call
                      </div>
                      <input
                        className={styles.expiringNextFriday}
                        placeholder="Expiring next Friday, strike price between 450 to 500?"
                        type="text"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <footer className={styles.frameFooter}>
                <div className={styles.textParent}>
                  <input
                    className={styles.text}
                    placeholder="Ask Solvent.Life ™ Neural Network..."
                    type="text"
                  />
                  <img
                    className={styles.flowbiteuploadOutlineIcon}
                    alt=""
                    src="/flowbiteuploadoutline.svg"
                  />
                </div>
                <div className={styles.text1}>
                  Solvent GPT ™ can make mistakes. Consider checking important
                  information.
                </div>
              </footer>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default LoginLifetime;
