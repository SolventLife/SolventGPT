import FrameComponent22 from "../components/FrameComponent22";
import FrameComponent21 from "../components/FrameComponent21";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent20 from "../components/FrameComponent20";
import styles from "./LoginFree.module.css";

const LoginFree = () => {
  return (
    <div className={styles.loginFree}>
      <FrameComponent22 />
      <main className={styles.frameParent}>
        <FrameComponent21 />
        <section className={styles.frameGroup}>
          <FrameComponent1
            propDebugCommit="unset"
            propGap="unset"
            propDebugCommit1="unset"
          />
          <FrameComponent20 />
        </section>
      </main>
    </div>
  );
};

export default LoginFree;
