import FrameComponent16 from "../components/FrameComponent16";
import FrameComponent15 from "../components/FrameComponent15";
import FrameComponent14 from "../components/FrameComponent14";
import styles from "./UpgradedPremium.module.css";

const UpgradedPremium = () => {
  return (
    <div className={styles.upgradedPremium}>
      <main className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.female13Parent}>
            <img
              className={styles.female13Icon}
              loading="lazy"
              alt=""
              src="/female13@2x.png"
            />
            <div className={styles.exclusiveFeaturesButtonWrapper}>
              <div className={styles.exclusiveFeaturesButton}>
                <b className={styles.anna}>Anna</b>
                <div className={styles.whatIsA}>
                  what is a trade and trading market platform, please explain
                  detail?
                </div>
              </div>
            </div>
          </div>
          <div className={styles.frameWrapper}>
            <div className={styles.frameContainer}>
              <div className={styles.rectangleWrapper}>
                <div className={styles.frameChild} />
              </div>
              <img
                className={styles.female13Icon1}
                alt=""
                src="/female13-11@2x.png"
              />
              <div className={styles.frameDiv}>
                <div className={styles.solvenGptParent}>
                  <b className={styles.solvenGpt}>Solven GPT</b>
                  <div className={styles.aTradeIsContainer}>
                    <p className={styles.aTradeIs}>
                      A trade is a transaction where goods, services, or
                      financial instruments are exchanged between parties,
                      typically in return for money or other goods/services. In
                      the context of financial markets, trading involves buying
                      and selling financial instruments like stocks, bonds,
                      commodities, or currencies with the aim of making a
                      profit.
                    </p>
                    <p className={styles.aTradingMarket}>
                      A trading market platform is a digital platform that
                      facilitates the buying and selling of financial
                      instruments. These platforms provide traders with access
                      to markets, tools, and resources necessary for executing
                      trades efficiently. Here's a detailed breakdown:
                    </p>
                    <ol className={styles.marketAccessTradingPlatfor}>
                      <li className={styles.marketAccessTrading}>
                        Market Access: Trading platforms connect traders to
                        various financial markets such as stock exchanges,
                        commodities exchanges, foreign exchange markets, and
                        cryptocurrency exchanges. They provide access to
                        real-time market data, including prices, volumes, and
                        historical trends, enabling traders to make informed
                        decisions.
                      </li>
                      <li className={styles.orderPlacementTraders}>
                        Order Placement: Traders can place buy or sell orders
                        directly through the platform. They can specify
                        parameters like quantity, price, and order type (market
                        order, limit order, stop order, etc.). The platform then
                        routes these orders to the relevant market for
                        execution.
                      </li>
                      <li className={styles.executionOnceAn}>
                        Execution: Once an order is placed, the platform
                        executes the trade based on the prevailing market
                        conditions. For example, if a trader submits a market
                        order to buy 100 shares of a stock, the platform will
                        execute the trade at the best available market price.
                      </li>
                      <li className={styles.chartingAndAnalysis}>
                        Charting and Analysis Tools: Trading platforms often
                        provide a range of analytical tools and charts to help
                        traders analyze market trends, identify trading
                        opportunities, and manage risk. These tools may include
                        technical indicators, charting patterns, and drawing
                        tools.
                      </li>
                      <li>
                        Risk Management: Effective risk management is crucial in
                        trading. Platforms offer features like stop-loss orders,
                        which automatically sell a security if it reaches a
                        certain price to limit potential losses. They may also
                        provide risk assessment tools and portfolio analysis to
                        help traders manage their exposure.
                      </li>
                    </ol>
                  </div>
                  <div className={styles.content}>
                    <div className={styles.summaryButton}>
                      <div className={styles.phxParent}>
                        <img
                          className={styles.phxIcon}
                          loading="lazy"
                          alt=""
                          src="/phx3.svg"
                        />
                        <div className={styles.female13Wrapper}>
                          <div className={styles.female13}>
                            <div className={styles.premiumWrapper}>
                              <div className={styles.premium}>Premium</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <h3 className={styles.congratulationsYoureNowAContainer}>
                      <p className={styles.congratulations}>Congratulations!</p>
                      <p className={styles.youreNowA}>
                        You’re now a Premium Member.
                      </p>
                    </h3>
                    <div className={styles.enjoyExclusiveFeaturesThatWrapper}>
                      <div className={styles.enjoyExclusiveFeatures}>
                        Enjoy exclusive features that will significantly enhance
                        your experience. Explore new capabilities now!
                      </div>
                    </div>
                    <div className={styles.buttonWrapper}>
                      <button className={styles.button}>
                        <b className={styles.continue}>Continue</b>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <FrameComponent16 />
      </main>
      <FrameComponent15 />
      <FrameComponent14 />
      <div className={styles.upgradedPremiumChild} />
    </div>
  );
};

export default UpgradedPremium;
