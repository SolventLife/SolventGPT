import FrameComponent8 from "../components/FrameComponent8";
import FrameComponent2 from "../components/FrameComponent2";
import styles from "./UpgradeLogin.module.css";

const UpgradeLogin = () => {
  return (
    <div className={styles.upgradeLogin}>
      <main className={styles.frameParent}>
        <FrameComponent8 />
        <section className={styles.frameWrapper}>
          <div className={styles.frameGroup}>
            <FrameComponent2
              logo="/logo2@2x.png"
              helix21="/helix2-11@2x.png"
              premium="Free"
              unlimitedPrompts="1/5 Prompts"
              changePlan="Upgrade Plan"
              frameDivMargin="0 !important"
              frameDivPosition="absolute"
              frameDivTop="-160px"
              frameDivLeft="-48px"
              frameDivPadding="0px var(--padding-xl) var(--padding-4xs-5) var(--padding-lgi-9)"
              frameDivPadding1="0px var(--padding-xl) var(--padding-111xl-3) var(--padding-lgi-9)"
              divWidth="unset"
              divPadding="0px var(--padding-11xl)"
              premiumMinWidth="51px"
              unlimitedPromptsMinWidth="91px"
              buttonBackgroundColor="1px solid #003df6"
              buttonPadding="var(--padding-8xs-5) var(--padding-7xl)"
              changePlanMinWidth="73px"
              changePlanFontWeight="bold"
            />
            <div className={styles.buttonUpgradeToPremium}>
              <div className={styles.buttonUpgradeToLifetime}>
                <div className={styles.helpIcon}>
                  <div className={styles.helpIconInner}>
                    <div className={styles.frameChild} />
                  </div>
                  <div className={styles.frameContainer}>
                    <div className={styles.female13Parent}>
                      <img
                        className={styles.female13Icon}
                        alt=""
                        src="/female13@2x.png"
                      />
                      <img
                        className={styles.female13Icon1}
                        loading="lazy"
                        alt=""
                        src="/female13-11@2x.png"
                      />
                    </div>
                    <div className={styles.frameDiv}>
                      <div className={styles.frameParent1}>
                        <div className={styles.annaParent}>
                          <b className={styles.anna}>Anna</b>
                          <div className={styles.whatIsA}>
                            what is a trade and trading market platform, please
                            explain detail?
                          </div>
                        </div>
                        <div className={styles.solvenGptParent}>
                          <b className={styles.solvenGpt}>Solven GPT</b>
                          <div className={styles.aTradeIsContainer}>
                            <p className={styles.aTradeIs}>
                              A trade is a transaction where goods, services, or
                              financial instruments are exchanged between
                              parties, typically in return for money or other
                              goods/services. In the context of financial
                              markets, trading involves buying and selling
                              financial instruments like stocks, bonds,
                              commodities, or currencies with the aim of making
                              a profit.
                            </p>
                            <p className={styles.aTradingMarket}>
                              A trading market platform is a digital platform
                              that facilitates the buying and selling of
                              financial instruments. These platforms provide
                              traders with access to markets, tools, and
                              resources necessary for executing trades
                              efficiently. Here's a detailed breakdown:
                            </p>
                            <ol className={styles.marketAccessTradingPlatfor}>
                              <li className={styles.marketAccessTrading}>
                                Market Access: Trading platforms connect traders
                                to various financial markets such as stock
                                exchanges, commodities exchanges, foreign
                                exchange markets, and cryptocurrency exchanges.
                                They provide access to real-time market data,
                                including prices, volumes, and historical
                                trends, enabling traders to make informed
                                decisions.
                              </li>
                              <li className={styles.orderPlacementTraders}>
                                Order Placement: Traders can place buy or sell
                                orders directly through the platform. They can
                                specify parameters like quantity, price, and
                                order type (market order, limit order, stop
                                order, etc.). The platform then routes these
                                orders to the relevant market for execution.
                              </li>
                              <li className={styles.executionOnceAn}>
                                Execution: Once an order is placed, the platform
                                executes the trade based on the prevailing
                                market conditions. For example, if a trader
                                submits a market order to buy 100 shares of a
                                stock, the platform will execute the trade at
                                the best available market price.
                              </li>
                              <li className={styles.chartingAndAnalysis}>
                                Charting and Analysis Tools: Trading platforms
                                often provide a range of analytical tools and
                                charts to help traders analyze market trends,
                                identify trading opportunities, and manage risk.
                                These tools may include technical indicators,
                                charting patterns, and drawing tools.
                              </li>
                              <li>
                                Risk Management: Effective risk management is
                                crucial in trading. Platforms offer features
                                like stop-loss orders, which automatically sell
                                a security if it reaches a certain price to
                                limit potential losses. They may also provide
                                risk assessment tools and portfolio analysis to
                                help traders manage their exposure.
                              </li>
                            </ol>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.frameParent2}>
                <div className={styles.textParent}>
                  <div className={styles.text}>
                    Ask Solvent.Life ™ Neural Network...
                  </div>
                  <img
                    className={styles.flowbiteuploadOutlineIcon}
                    alt=""
                    src="/flowbiteuploadoutline.svg"
                  />
                </div>
                <div className={styles.text1}>
                  Solvent GPT ™ can make mistakes. Consider checking important
                  information.
                </div>
              </div>
            </div>
            <div className={styles.frameItem} />
            <div className={styles.content}>
              <div className={styles.phxParent}>
                <img
                  className={styles.phxIcon}
                  loading="lazy"
                  alt=""
                  src="/phx2.svg"
                />
                <div className={styles.frameWrapper1}>
                  <div className={styles.frameParent3}>
                    <div className={styles.streamlineaiNetworkSparkSoWrapper}>
                      <img
                        className={styles.streamlineaiNetworkSparkSoIcon}
                        loading="lazy"
                        alt=""
                        src="/streamlineainetworksparksolid.svg"
                      />
                    </div>
                    <b className={styles.upgradeYourPlan}>Upgrade your plan</b>
                  </div>
                </div>
              </div>
              <div className={styles.ourPricingIs}>
                Our pricing is accessible to all traders. Choose the option
                that’s right for you. if you trade infrequently or are taking a
                break, you can switch plans at any time.
              </div>
              <div className={styles.contentParent}>
                <div className={styles.content1}>
                  <div className={styles.frameParent4}>
                    <div className={styles.frameWrapper2}>
                      <div className={styles.freeParent}>
                        <h3 className={styles.free}>Free</h3>
                        <div className={styles.frameParent5}>
                          <div className={styles.parent}>
                            <div className={styles.div}>$0</div>
                            <div className={styles.monthWrapper}>
                              <div className={styles.month}>/month</div>
                            </div>
                          </div>
                          <div className={styles.forever}>Forever</div>
                        </div>
                      </div>
                    </div>
                    <img
                      className={styles.visualIcon}
                      loading="lazy"
                      alt=""
                      src="/visual@2x.png"
                    />
                  </div>
                  <div className={styles.contentInner}>
                    <div className={styles.frameParent6}>
                      <div className={styles.upgradeOptionsWrapper}>
                        <div className={styles.upgradeOptions}>
                          <div className={styles.prompts}>5 Prompts</div>
                        </div>
                      </div>
                      <div className={styles.aDay}>a day</div>
                    </div>
                  </div>
                  <button className={styles.button}>
                    <div className={styles.currentPlan}>Current Plan</div>
                  </button>
                  <input className={styles.phx} type="checkbox" />
                </div>
                <div className={styles.content2}>
                  <div className={styles.helix21Parent}>
                    <img
                      className={styles.helix21Icon}
                      alt=""
                      src="/helix2-1-1@2x.png"
                    />
                    <h3 className={styles.pro}>Pro</h3>
                    <button className={styles.mostPopularParent}>
                      <div className={styles.mostPopular}>Most Popular</div>
                      <img
                        className={styles.rifireFillIcon}
                        alt=""
                        src="/rifirefill.svg"
                      />
                    </button>
                    <div className={styles.div1}>$29</div>
                    <div className={styles.month1}>/month</div>
                    <div className={styles.billedMonthlyEx}>
                      Billed monthly, ex. tax
                    </div>
                  </div>
                  <div className={styles.contentChild}>
                    <div className={styles.frameParent7}>
                      <div className={styles.frameWrapper3}>
                        <div className={styles.promptsWrapper}>
                          <div className={styles.prompts1}>50 Prompts</div>
                        </div>
                      </div>
                      <div className={styles.aDay1}>a day</div>
                    </div>
                  </div>
                  <button className={styles.button1}>
                    <b className={styles.upgradeToPro}>Upgrade to Pro</b>
                  </button>
                </div>
                <div className={styles.content3}>
                  <div className={styles.emojistar1Parent}>
                    <img
                      className={styles.emojistar1Icon}
                      loading="lazy"
                      alt=""
                      src="/emojistar-1@2x.png"
                    />
                    <div className={styles.month2}>/month</div>
                    <div className={styles.premiumParent}>
                      <h3 className={styles.premium}>Premium</h3>
                      <div className={styles.wrapper}>
                        <div className={styles.div2}>$199</div>
                      </div>
                      <div className={styles.billedMonthlyEx1}>
                        Billed monthly, ex. tax
                      </div>
                    </div>
                  </div>
                  <div className={styles.contentInner1}>
                    <div className={styles.frameParent8}>
                      <div className={styles.frameWrapper4}>
                        <div className={styles.unlimitedWrapper}>
                          <div className={styles.unlimited}>Unlimited</div>
                        </div>
                      </div>
                      <div className={styles.aDay2}>a day</div>
                    </div>
                  </div>
                  <button className={styles.button2}>
                    <div className={styles.upgradeToPremium}>
                      Upgrade to Premium
                    </div>
                  </button>
                </div>
                <div className={styles.content4}>
                  <div className={styles.pyramid1Parent}>
                    <img
                      className={styles.pyramid1Icon}
                      loading="lazy"
                      alt=""
                      src="/pyramid-1@2x.png"
                    />
                    <div className={styles.lifetimeParent}>
                      <h3 className={styles.lifetime}>Lifetime</h3>
                      <div className={styles.container}>
                        <div className={styles.div3}>$599</div>
                      </div>
                      <div className={styles.billedMonthlyEx2}>
                        Billed monthly, ex. tax
                      </div>
                    </div>
                    <div className={styles.oneTimePaymentWrapper}>
                      <div className={styles.oneTimePayment}>
                        <p className={styles.oneTime}>one time</p>
                        <p className={styles.payment}>payment</p>
                      </div>
                    </div>
                  </div>
                  <div className={styles.contentInner2}>
                    <div className={styles.frameParent9}>
                      <div className={styles.frameWrapper5}>
                        <div className={styles.unlimitedContainer}>
                          <div className={styles.unlimited1}>Unlimited</div>
                        </div>
                      </div>
                      <div className={styles.aDay3}>a day</div>
                    </div>
                  </div>
                  <button className={styles.button3}>
                    <div className={styles.upgradeToLifetime}>
                      Upgrade to Lifetime
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default UpgradeLogin;
