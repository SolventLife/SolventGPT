import styles from "./FrameComponent5.module.css";

const FrameComponent5 = () => {
  return (
    <header className={styles.frameParent}>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <img
            className={styles.frameChild}
            alt=""
            src="/group-1000005043.svg"
          />
          <div className={styles.upgradeToProWrapper}>
            <b className={styles.upgradeToPro}>Upgrade to Pro</b>
          </div>
        </div>
      </div>
      <div className={styles.female13}>
        <div className={styles.pROLabel}>
          <div className={styles.pro}>PRO</div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent5;
