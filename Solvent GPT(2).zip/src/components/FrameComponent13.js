import styles from "./FrameComponent13.module.css";

const FrameComponent13 = () => {
  return (
    <footer className={styles.upgradeButtonWrapper}>
      <div className={styles.upgradeButton}>
        <div className={styles.femaleIcon}>
          <div className={styles.menuList}>
            Ask Solvent.Life ™ Neural Network...
          </div>
          <img
            className={styles.flowbiteuploadOutlineIcon}
            alt=""
            src="/flowbiteuploadoutline.svg"
          />
        </div>
        <div className={styles.fluentNoteEdit}>
          Solvent GPT ™ can make mistakes. Consider checking important
          information.
        </div>
      </div>
    </footer>
  );
};

export default FrameComponent13;
