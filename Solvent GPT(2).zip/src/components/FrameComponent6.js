import styles from "./FrameComponent6.module.css";

const FrameComponent6 = () => {
  return (
    <section className={styles.uploadIconWrapper}>
      <div className={styles.uploadIcon}>
        <div className={styles.tradeDescParent}>
          <div className={styles.tradeDesc}>
            Ask Solvent.Life ™ Neural Network...
          </div>
          <img
            className={styles.flowbiteuploadOutlineIcon}
            alt=""
            src="/flowbiteuploadoutline.svg"
          />
        </div>
        <div className={styles.upgradeToPro}>
          Solvent GPT ™ can make mistakes. Consider checking important
          information.
        </div>
      </div>
    </section>
  );
};

export default FrameComponent6;
