import styles from "./FrameComponent26.module.css";

const FrameComponent26 = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.logoWrapper}>
        <img
          className={styles.logoIcon}
          loading="lazy"
          alt=""
          src="/logo@2x.png"
        />
      </div>
      <div className={styles.frameWrapper}>
        <div className={styles.yesterdayParent}>
          <div className={styles.yesterday}>Yesterday</div>
          <div className={styles.giveMeASummaryParent}>
            <div className={styles.giveMeA}>Give me a summary</div>
            <div className={styles.showMeThe}>Show me the top gain...</div>
            <div className={styles.whatIsThe}>What is the premium...</div>
            <div className={styles.whatIsThe1}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.previous30DaysParent}>
          <div className={styles.previous30Days}>Previous 30 Days</div>
          <div className={styles.giveMeASummaryGroup}>
            <div className={styles.giveMeA1}>Give me a summary</div>
            <div className={styles.showMeThe1}>Show me the top gaine...</div>
            <div className={styles.whatIsThe2}>What is the premium...</div>
            <div className={styles.whatIsThe3}>What is the premium...</div>
          </div>
        </div>
      </div>
      <div className={styles.frameDiv}>
        <div className={styles.helix21Parent}>
          <img
            className={styles.helix21Icon}
            loading="lazy"
            alt=""
            src="/helix2-13@2x.png"
          />
          <div className={styles.textParent}>
            <div className={styles.text}>Your current plan</div>
            <div className={styles.frameWrapper1}>
              <div className={styles.lifetimeWrapper}>
                <h3 className={styles.lifetime}>Lifetime</h3>
              </div>
            </div>
            <div className={styles.unlimitedPrompts}>Unlimited Prompts</div>
          </div>
          <button className={styles.button}>
            <div className={styles.button1}>
              <div className={styles.changePlan}>Change Plan</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent26;
